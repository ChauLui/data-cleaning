# 2/25/17 CKL - Have not tried the snippet below from 
#http://stackoverflow.com/questions/3053833/using-r-to-download-zipped-data-file-extract-and-import-data
#library(data.table)
#temp <- tempfile()
#download.file("https://www.bls.gov/tus/special.requests/atusact_0315.zip", temp)
#timeUse <- fread(unzip(temp, files = "atusact_0315.dat"))
#rm(temp)

#http://stackoverflow.com/questions/8197027/raw-text-strings-for-file-paths-in-r
#zz <- file.path("E:", "DATA", "example.csv")
#normalizePath(zz)
#[1] "E:\\DATA\\example.csv"


setwd("D:/RLearning/CleaningDataWeek4/Project")


if(!file.exists("data")) {dir.create("data")}

unzip(zipfile="getdata-projectfiles-UCI HAR Dataset.zip",exdir="data")


# fileLocation <- file.path("data", list.files("data"))
# list.files(fileLocation)
#[1] "activity_labels.txt" "features.txt"        "features_info.txt"   "README.txt"          "test"               
#[6] "train"
#
# folders and files location: 
# data/UCI HAR Dataset/train/
#      subject_train.txt (7,352 rows)
#      X_train.txt
#      y_train.txt
# data/UCI HAR Dataset/train/Inertial Signals

# data/UCI HAR Dataset/test/
#      subject_test.txt
#      X_test.txt
#      y_test.txt

# "features_info.txt" is like README.txt with a general explanation of the 561 columns in the 'X'files
# "features.txt" is the detail name of each column in the 'X'files 
# X_train.txt and X_test.txt contains the measurements of the features
# y_train.txt and y_test.txt contains the activities of each X line.

# rename the default column names: V1, V2
features <- read.table(file.path(fileLocation,"features.txt"))
names(features) <- c("featureCode", "featureName")

activityLabels <- read.table(file.path(fileLocation,"activity_labels.txt"))
names(activityLabels) <- c("activityCode", "activityName")
#rem activityLabels <- dplyr::rename(activityLabels, activityCode = V1, activityName = V2)

# start function here with arg: "train" or "test"

fileSet <- c("train")

fileLocation <- file.path("data","UCI HAR Dataset", "train")

subjectTrain <- read.table(file.path(fileLocation, "subject_train.txt"))
names(subjectTrain) <- c("subjectNum")

# create a row ID column in case rows get re-arranged. src and ID columns will be used in merge.
subjectTrain<- dplyr::mutate(subjectTrain, ID = as.numeric(rownames(subjectTrain), src = fileSet))

Xtrain <- read.table(file.path(fileLocation, "X_train.txt"), stringsAsFactors=FALSE)

# Extracts only the measurements on the mean and standard deviation for each measurement
reqCols <- grep("[Mm]ean|[Ss]td", features$featureName)

selXtrain <- dplyr::select(Xtrain, reqCols)
# rm(Xtrain)
selXtrain <- dplyr::mutate(selXtrain, ID = as.numeric(rownames(selXtrain)), src = "train")

yTrain <- read.table(file.path(fileLocation, "y_train.txt"))
names(yTrain) <- c("activityCode")
yTrain <- dplyr::mutate(yTrain, ID = as.numeric(rownames(yTrain)), src = "train")

yTrain <- merge(yTrain, activityLabels)

selXtrain <- merge(selXtrain, yTrain)
selXtrain <- merge(selXtrain, subjectTrain)

# change from wide to narrow data frame
XtrainGather <- tidyr::gather(selXtrain, feature, featureValue, -(c(ID, src, activityCode, activityName, subjectNum)))

# End function here with arg: "train" or "test"





#XtrainGather <- dplyr::mutate(XtrainGather, featureID = strsplit(XtrainGather$feature, "^V" )[[2]]
#> head(strsplit(XtrainGather$feature, "V" ))
#[[1]]
#[1] ""  "1"
#
#[[2]]
#[1] ""  "1"
# difficult to pick up the 2nd element of the list of list


features <- dplyr::mutate(features, featureKey = paste("V", features$featureCode, sep ="" ))

XtrainGather<- merge(XtrainGather, features, by.x = "feature", by.y = "featureKey", all = TRUE) )



# To do : stop if file is not there - not necessary?


> length(XtrainGather$ID)
[1] 632272




setwd("D:/RLearning/CleaningDataWeek4/Project")
> getwd()
[1] "D:/RLearning/CleaningDataWeek4/Project/getdata-projectfiles-UCI HAR Dataset/UCI HAR Dataset"
> 




> list.files("D:/RLearning/CleaningDataWeek4/Project")
[1] "getdata-projectfiles-UCI HAR Dataset"    
[2] "getdata-projectfiles-UCI HAR Dataset.zip"
[3] "subject_train.txt"                       
[4] "X_train.txt"                             
[5] "y_train.txt"                             
> 
# NG? dateDownloaded <-data("getdata-projectfiles-UCI HAR Dataset.zip")

SubjTrain <- read.table("subject_train.txt")

xTrain <- read.table("X_train.txt")

[541] "V541" "V542" "V543" "V544" "V545" "V546" "V547" "V548" "V549" "V550"
[551] "V551" "V552" "V553" "V554" "V555" "V556" "V557" "V558" "V559" "V560"
[561] "V561"

> length(xTrain$V561)
[1] 7352

> length(SubjTrain$V1)
[1] 7352

setwd("D:/RLearning/CleaningDataWeek4/Project/getdata-projectfiles-UCI HAR Dataset/UCI HAR Dataset")

> list.files()
[1] "activity_labels.txt" "features.txt"        "features_info.txt"  
[4] "README.txt"          "test"                "train"              
# "features_info.txt" is like ReadMe with general explanation of the 561 columns
# "features.txt" is the details of each columns

yTrain <- read.table("train/y_train.txt")
> length(yTrain$V1)
[1] 7352

> max(yTrain$V1)
[1] 6

> rownames(yTrain)
   [1] "1"    "2"    "3"    "4"    "5"    "6"    "7"    "8"    "9"    "10"  
  [11] "11"   "12"   "13"   "14"   "15"   "16"   "17"   "18"   "19"   "20"  
 ...
[7331] "7331" "7332" "7333" "7334" "7335" "7336" "7337" "7338" "7339" "7340"
[7341] "7341" "7342" "7343" "7344" "7345" "7346" "7347" "7348" "7349" "7350"
[7351] "7351" "7352"

> paste("V", grep("[Mm]ean|[Ss]td", Features$V2), sep ="" )
 [1] "V1"   "V2"   "V3"   "V4"   "V5"   "V6"   "V41"  "V42"  "V43"  "V44" 
[11] "V45"  "V46"  "V81"  "V82"  "V83"  "V84"  "V85"  "V86"  "V121" "V122"
[21] "V123" "V124" "V125" "V126" "V161" "V162" "V163" "V164" "V165" "V166"
[31] "V201" "V202" "V214" "V215" "V227" "V228" "V240" "V241" "V253" "V254"
[41] "V266" "V267" "V268" "V269" "V270" "V271" "V294" "V295" "V296" "V345"
[51] "V346" "V347" "V348" "V349" "V350" "V373" "V374" "V375" "V424" "V425"
[61] "V426" "V427" "V428" "V429" "V452" "V453" "V454" "V503" "V504" "V513"
[71] "V516" "V517" "V526" "V529" "V530" "V539" "V542" "V543" "V552" "V555"
[81] "V556" "V557" "V558" "V559" "V560" "V561"

> reqCols <- paste("V", grep("[Mm]ean|[Ss]td", Features$V2), sep ="" )
> head (dplyr::select (xTrain, reqCols))
Error: All select() inputs must resolve to integer column positions.
The following do not:
*  reqCols

reqCols <- grep("[Mm]ean|[Ss]td", Features$V2)

> head (dplyr::select (xTrain, reqCols))
         V1          V2         V3         V4         V5         V6       V41
1 0.2885845 -0.02029417 -0.1329051 -0.9952786 -0.9831106 -0.9135264 0.9633961
2 0.2784188 -0.01641057 -0.1235202 -0.9982453 -0.9753002 -0.9603220 0.9665611
3 0.2796531 -0.01946716 -0.1134617 -0.9953796 -0.9671870 -0.9789440 0.9668781
4 0.2791739 -0.02620065 -0.1232826 -0.9960915 -0.9834027 -0.9906751 0.9676152
5 0.2766288 -0.01656965 -0.1153619 -0.9981386 -0.9808173 -0.9904816 0.9682244
6 0.2771988 -0.01009785 -0.1051373 -0.9973350 -0.9904868 -0.9954200 0.9679482
 

activityLabels <- read.table("activity_labels.txt")
activityLabels <- dplyr::rename(activityLabels, activityCode = V1, activityName = V2)

subjectTrain<- read.table("train/subject_train.txt")
subjectTrain<- dplyr::rename(subjectTrain, subjectNum = V1)

# create a row ID column in case rows get re-arranged. ID column will be used in merge.
subjectTrain<- dplyr::mutate(subjectTrain, ID = as.numeric(rownames(subjectTrain)))



myDataXtrain <- dplyr::select (xTrain, reqCols)
myDataXtrain <- dplyr::mutate(myDataXtrain , ID = as.numeric(rownames(myDataXtrain)))

yTrain <- dplyr::mutate(yTrain , ID = as.numeric(rownames(yTrain)))
yTrain <- dplyr::rename(yTrain , activityCode = V1)

yTrain <- merge(yTrain, activityLabels)

myDataXtrain <- merge(myDataXtrain, yTrain)
myDataXtrain <- merge(myDataXtrain, subjectTrain)

> summarizeXtrain <- dplyr::summarize(myDataXtrain)
> View(summarizeXtrain)
Error in View(summarizeXtrain) : invalid 'x' argument
> dplyr::summarize(myDataXtrain)
data frame with 0 columns and 0 rows

# ?? grpMyDataXtrain <- dplyr::group_by(subjectNum, activityName)



#reqCols <- paste("V", grep("[Mm]ean|[Ss]td", Features$V2), sep ="" )
VreqCols <- paste("V", reqCols , sep ="" )

# XtrainMelt <- reshape2::melt(myDataXtrain, id=c("ID", "activityName","src"), measure.vars=c("V1", "V2", "V3", "V4","V5","V6", "V41", "V42"))

XtrainMelt <- reshape2::melt(myDataXtrain, id=c("ID", "activityName","subjectNum"), measure.vars=VreqCols))
# 'gather' - another method similar to 'melt'
> XtrainGather <- tidyr::gather(myDataXtrain, feature, featureValue, -(c(ID, src, activityCode, activityName, subjectNum, subjectID)))
>
##??not working?? XtrainGather <- tidyr::gather(myDataXtrain, feature, featureValue, -(c("ID", "activityName","subjectNum")))
##??not working?? XtrainGather <- tidyr::gather(myDataXtrain, feature, featureValue, -(ID, activityName,subjectNum))
> XtrainGather <- tidyr::gather(myDataXtrain, feature, featureValue, -(c("ID", "activityName","subjectNum")))
Error in -(c("ID", "activityName", "subjectNum")) : 
  invalid argument to unary operator
> XtrainGather <- tidyr::gather(myDataXtrain, feature, featureValue, -(ID, activityName, subjectNum))
Error: unexpected ',' in "XtrainGather <- tidyr::gather(myDataXtrain, feature, featureValue, -(ID,"
>


> View(XtrainMelt)



myDataXtrain <- merge(myDataXtrain, yTrain)


myDataXtrain <- cbind(src=c("XTrain"), myDataXtrain)

xTest <- read.table("test/X_test.txt")

myDataXtest <- dplyr::select (xTest, reqCols)

myDataXtest <- cbind(src=c("XTest"), myDataXtest)

myData <- rbind(myDataXtrain, myDataXtest)








setwd("D:/RLearning/CleaningDataWeek4/Project/getdata-projectfiles-UCI HAR Dataset/UCI HAR Dataset/Train/Inertial Signals")

list.files("D:/RLearning/CleaningDataWeek4/Project/getdata-projectfiles-UCI HAR Dataset/UCI HAR Dataset/Train/Inertial Signals")
[1] "body_acc_x_train.txt"  "body_acc_y_train.txt"  "body_acc_z_train.txt" 
[4] "body_gyro_x_train.txt" "body_gyro_y_train.txt" "body_gyro_z_train.txt"
[7] "total_acc_x_train.txt" "total_acc_y_train.txt" "total_acc_z_train.txt"
> 

bodyAccXTrain <- read.table("body_acc_x_train.txt")
> length(bodyAccXTrain$V128)
[1] 7352

bodyAccYTrain <- read.table("body_acc_y_train.txt")

> length(bodyAccYTrain$V128)
[1] 7352